МОД «БЕЛКИ» для Minecraft Java 1.21.11 (Fabric)

ВАЖНО: проект НЕ был собран автоматически (в среде, где он писался, нет интернета).
Возможны мелкие ошибки компиляции - пришлите текст ошибки, я исправлю.

КАК СОБРАТЬ JAR (самый простой способ)
1. Установите Java 21 (Temurin/Adoptium) и IntelliJ IDEA Community (бесплатно).
2. Распакуйте архив. В IntelliJ: File -> Open -> выберите папку squirrelmod.
   Согласитесь "Trust Project" и подождите, пока внизу закончится загрузка (Gradle сам всё скачает).
3. Справа откройте вкладку Gradle -> Tasks -> build -> двойной клик по "build".
4. Готовый файл: папка build/libs/squirrelmod-1.0.0.jar
   (файл с "-sources" в имени не нужен).

КАК УСТАНОВИТЬ
1. Установите Fabric Loader для 1.21.11 (fabricmc.net/use).
2. Скачайте Fabric API для 1.21.11 (версия 0.141.1+1.21.11 или новее) с Modrinth.
3. Положите squirrelmod-1.0.0.jar и fabric-api в папку .minecraft/mods
4. Запустите профиль Fabric 1.21.11.

ПРОВЕРКА В ИГРЕ
- Призвать белку: /summon squirrelmod:squirrel
- Дать предмет: /give @s squirrelmod:chekushka
- Обмен: возьмите хлеб и нажмите ПКМ по белке.
