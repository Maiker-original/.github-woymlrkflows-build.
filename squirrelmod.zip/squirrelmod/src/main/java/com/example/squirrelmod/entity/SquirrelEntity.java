package com.example.squirrelmod.entity;

import com.example.squirrelmod.SquirrelMod;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.EscapeDangerGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.TemptGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

public class SquirrelEntity extends PathAwareEntity {
    /** Пауза между обменами (в тиках, 20 тиков = 1 секунда). */
    private static final int TRADE_COOLDOWN_TICKS = 20;
    private int tradeCooldown = 0;

    public SquirrelEntity(EntityType<? extends SquirrelEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createSquirrelAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.MAX_HEALTH, 6.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.28);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new EscapeDangerGoal(this, 1.4));
        this.goalSelector.add(2, new TemptGoal(this, 1.1, stack -> stack.isOf(Items.BREAD), false));
        this.goalSelector.add(3, new WanderAroundFarGoal(this, 0.9));
        this.goalSelector.add(4, new LookAtEntityGoal(this, PlayerEntity.class, 6.0f));
        this.goalSelector.add(5, new LookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (tradeCooldown > 0) {
            tradeCooldown--;
        }
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack held = player.getStackInHand(hand);
        if (!held.isOf(Items.BREAD)) {
            return super.interactMob(player, hand);
        }
        // Только сервер выдаёт предмет. Клиенту просто говорим «обработано».
        if (!(player instanceof ServerPlayerEntity)) {
            return ActionResult.SUCCESS;
        }
        // Защита от двойной выдачи (две руки, быстрые клики).
        if (tradeCooldown > 0) {
            return ActionResult.CONSUME;
        }
        tradeCooldown = TRADE_COOLDOWN_TICKS;

        held.decrementUnlessCreative(1, player);
        player.getInventory().offerOrDrop(new ItemStack(SquirrelMod.CHEKUSHKA));

        this.playSound(SoundEvents.ENTITY_FOX_EAT, 1.0f, 1.3f);
        this.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.5f);
        if (this.getEntityWorld() instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.HAPPY_VILLAGER,
                    this.getX(), this.getY() + 0.6, this.getZ(), 8, 0.3, 0.3, 0.3, 0.02);
        }
        return ActionResult.SUCCESS;
    }

    /** Белки появляются на траве/земле при достаточном свете. */
    public static boolean canSpawn(EntityType<SquirrelEntity> type, WorldAccess world,
                                   SpawnReason reason, BlockPos pos, Random random) {
        BlockState below = world.getBlockState(pos.down());
        return below.isIn(net.minecraft.registry.tag.BlockTags.ANIMALS_SPAWNABLE_ON)
                && world.getBaseLightLevel(pos, 0) > 8;
    }

    @Override
    public int getLimitPerChunk() {
        return 4;
    }
}
