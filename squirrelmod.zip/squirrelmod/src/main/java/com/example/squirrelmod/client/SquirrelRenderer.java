package com.example.squirrelmod.client;

import com.example.squirrelmod.SquirrelMod;
import com.example.squirrelmod.entity.SquirrelEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class SquirrelRenderer extends MobEntityRenderer<SquirrelEntity, SquirrelRenderState, SquirrelModel> {
    private static final Identifier TEXTURE =
            Identifier.of(SquirrelMod.MOD_ID, "textures/entity/squirrel.png");

    public SquirrelRenderer(EntityRendererFactory.Context context) {
        super(context, new SquirrelModel(context.getPart(SquirrelModel.LAYER)), 0.3f);
    }

    @Override
    public SquirrelRenderState createRenderState() {
        return new SquirrelRenderState();
    }

    @Override
    public Identifier getTexture(SquirrelRenderState state) {
        return TEXTURE;
    }
}
