package com.example.squirrelmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

import com.example.squirrelmod.entity.SquirrelEntity;

public class SquirrelMod implements ModInitializer {
    public static final String MOD_ID = "squirrelmod";

    public static final Identifier SQUIRREL_ID = Identifier.of(MOD_ID, "squirrel");
    public static final Identifier CHEKUSHKA_ID = Identifier.of(MOD_ID, "chekushka");

    public static final EntityType<SquirrelEntity> SQUIRREL = EntityType.Builder
            .create(SquirrelEntity::new, SpawnGroup.CREATURE)
            .dimensions(0.5f, 0.6f)
            .maxTrackingRange(8)
            .build(RegistryKey.of(RegistryKeys.ENTITY_TYPE, SQUIRREL_ID));

    public static final Item CHEKUSHKA = new Item(new Item.Settings()
            .registryKey(RegistryKey.of(RegistryKeys.ITEM, CHEKUSHKA_ID))
            .maxCount(16));

    @Override
    public void onInitialize() {
        Registry.register(Registries.ENTITY_TYPE, SQUIRREL_ID, SQUIRREL);
        Registry.register(Registries.ITEM, CHEKUSHKA_ID, CHEKUSHKA);

        FabricDefaultAttributeRegistry.register(SQUIRREL, SquirrelEntity.createSquirrelAttributes());

        SpawnRestriction.register(SQUIRREL, SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, SquirrelEntity::canSpawn);

        // Леса: часто. Группы по 2-4 белки.
        BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_FOREST),
                SpawnGroup.CREATURE, SQUIRREL, 40, 2, 4);
        // Тайга: редко.
        BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_TAIGA),
                SpawnGroup.CREATURE, SQUIRREL, 3, 1, 2);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS)
                .register(entries -> entries.add(CHEKUSHKA));
    }
}
