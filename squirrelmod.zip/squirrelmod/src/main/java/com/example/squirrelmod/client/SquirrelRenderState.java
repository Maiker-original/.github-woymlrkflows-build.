package com.example.squirrelmod.client;

import net.minecraft.client.render.entity.state.LivingEntityRenderState;

public class SquirrelRenderState extends LivingEntityRenderState {
}
