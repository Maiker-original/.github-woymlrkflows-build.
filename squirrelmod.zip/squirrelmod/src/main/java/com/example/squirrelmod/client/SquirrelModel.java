package com.example.squirrelmod.client;

import com.example.squirrelmod.SquirrelMod;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public class SquirrelModel extends EntityModel<SquirrelRenderState> {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(Identifier.of(SquirrelMod.MOD_ID, "squirrel"), "main");

    private final ModelPart head;
    private final ModelPart earLeft;
    private final ModelPart earRight;
    private final ModelPart tail;
    private final ModelPart legFrontLeft;
    private final ModelPart legFrontRight;
    private final ModelPart legBackLeft;
    private final ModelPart legBackRight;

    public SquirrelModel(ModelPart root) {
        super(root);
        this.head = root.getChild("head");
        this.earLeft = this.head.getChild("ear_left");
        this.earRight = this.head.getChild("ear_right");
        this.tail = root.getChild("tail");
        this.legFrontLeft = root.getChild("leg_front_left");
        this.legFrontRight = root.getChild("leg_front_right");
        this.legBackLeft = root.getChild("leg_back_left");
        this.legBackRight = root.getChild("leg_back_right");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        root.addChild("body",
                ModelPartBuilder.create().uv(0, 0).cuboid(-2f, -2f, -3.5f, 4f, 4f, 7f),
                ModelTransform.origin(0f, 19f, 0f));

        ModelPartData head = root.addChild("head",
                ModelPartBuilder.create().uv(24, 0).cuboid(-2f, -3f, -4f, 4f, 4f, 4f),
                ModelTransform.origin(0f, 18f, -3f));
        head.addChild("snout",
                ModelPartBuilder.create().uv(42, 0).cuboid(-1f, -1f, -5f, 2f, 2f, 1f),
                ModelTransform.origin(0f, 0f, 0f));
        head.addChild("ear_left",
                ModelPartBuilder.create().uv(50, 0).cuboid(0.5f, -5f, -2f, 1f, 2f, 1f),
                ModelTransform.origin(0f, 0f, 0f));
        head.addChild("ear_right",
                ModelPartBuilder.create().uv(50, 0).cuboid(-1.5f, -5f, -2f, 1f, 2f, 1f),
                ModelTransform.origin(0f, 0f, 0f));

        ModelPartData tail = root.addChild("tail",
                ModelPartBuilder.create().uv(0, 18).cuboid(-1.5f, -7f, 0f, 3f, 8f, 3f),
                ModelTransform.origin(0f, 19f, 3f));
        tail.addChild("tail_tip",
                ModelPartBuilder.create().uv(14, 18).cuboid(-2f, -11f, -0.5f, 4f, 4f, 4f),
                ModelTransform.origin(0f, 0f, 0f));

        ModelPartBuilder leg = ModelPartBuilder.create().uv(0, 12).cuboid(-1f, 0f, -1f, 2f, 3f, 2f);
        root.addChild("leg_front_left", leg, ModelTransform.origin(1.2f, 21f, -2.2f));
        root.addChild("leg_front_right", leg, ModelTransform.origin(-1.2f, 21f, -2.2f));
        root.addChild("leg_back_left", leg, ModelTransform.origin(1.2f, 21f, 2.2f));
        root.addChild("leg_back_right", leg, ModelTransform.origin(-1.2f, 21f, 2.2f));

        return TexturedModelData.of(data, 64, 32);
    }

    @Override
    public void setAngles(SquirrelRenderState state) {
        super.setAngles(state);

        float walk = state.limbFrequency;          // «фаза» шагов
        float amount = state.limbAmplitudeMultiplier; // 0 = стоит, 1 = бежит

        // Голова смотрит на игрока / по сторонам
        this.head.yaw = state.relativeHeadYaw * ((float) Math.PI / 180f);
        this.head.pitch = state.pitch * ((float) Math.PI / 180f);

        // ХОДЬБА: лапы по диагонали, хвост пружинит
        float swing = MathHelper.cos(walk * 1.2f) * 1.2f * amount;
        this.legFrontLeft.pitch = swing;
        this.legBackRight.pitch = swing;
        this.legFrontRight.pitch = -swing;
        this.legBackLeft.pitch = -swing;

        // ОЖИДАНИЕ: хвост покачивается, ушки подёргиваются, нос «дышит»
        float t = state.age;
        this.tail.pitch = 0.35f + MathHelper.sin(t * 0.08f) * 0.08f + amount * 0.25f;
        this.tail.yaw = MathHelper.sin(t * 0.12f) * (0.18f * (1f - amount)) + MathHelper.cos(walk * 1.2f) * 0.2f * amount;
        float twitch = Math.max(0f, MathHelper.sin(t * 0.35f)) > 0.95f ? 0.35f : 0f;
        this.earLeft.roll = 0.1f + twitch;
        this.earRight.roll = -0.1f - twitch;
        this.head.pitch += MathHelper.sin(t * 0.15f) * 0.04f;
    }
}
