package com.example.squirrelmod.client;

import com.example.squirrelmod.SquirrelMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.render.entity.EntityRendererFactories;

public class SquirrelModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(SquirrelModel.LAYER, SquirrelModel::getTexturedModelData);
        EntityRendererFactories.register(SquirrelMod.SQUIRREL, SquirrelRenderer::new);
    }
}
